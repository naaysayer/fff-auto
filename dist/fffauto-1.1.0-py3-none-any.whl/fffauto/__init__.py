import fffauto.fff as fff
